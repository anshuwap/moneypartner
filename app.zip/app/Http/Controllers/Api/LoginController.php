<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Auth;

// use Tymon\JWTAuth\JWTAuth;

class LoginController extends Controller
{

    public function store(Request $request)

    {
        try {

            if(empty(MoneyPartnerOption()->payout_api) && MoneyPartnerOption()->payout_api !=1)
            return response()->json([
                'success' => false,
                'message' => 'You have not Provide this Service.',
            ], 500);

            $credentials = $request->only('email', 'password');

            if (!$token = JWTAuth::attempt($credentials)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Login credentials are invalid.',
                ], 400);
            }
        } catch (JWTException $e) {
            return $credentials;
            return response()->json([
                'success' => false,
                'message' => 'Could not create token.',
            ], 500);
        }

        //Token created, return with success response and jwt token
        return $this->createNewToken($token);
    }

    protected function createNewToken($token)
    {
        $user['name'] = auth()->user()->full_name;
        $user['email'] = auth()->user()->email;

        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth('api')->factory()->getTTL() * 60,
            'user' => $user
        ]);
    }

}
